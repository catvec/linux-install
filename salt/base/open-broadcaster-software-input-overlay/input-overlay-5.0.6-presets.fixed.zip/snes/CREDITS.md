Original preset from:
https://www.fagurd.com/OBS/inputoverlay/SNES/

Adapted to version 5.0 by [mcronce](https://github.com/mcronce)

