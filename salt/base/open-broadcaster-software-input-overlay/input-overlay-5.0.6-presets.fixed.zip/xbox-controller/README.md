Preset made by [Saikel Orado Liu](https://github.com/Saikel-Orado-Liu) licensed under the [CC0](https://creativecommons.org/public-domain/cc0/) license.
