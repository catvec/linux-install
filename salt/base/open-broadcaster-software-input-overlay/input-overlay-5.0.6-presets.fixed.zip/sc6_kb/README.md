This is a free to use overlay intended for SoulCalibur 6. It relies heavily on the default control scheme for Keyboard, so you are more than welcome to change it up as
you please, everything you'd need to do so are included in this readme. You must also be using Input Overlay 5.0.0+ for json support.

I do not claim ownership over any of the assets I used. All of the assets used however, are listed as being free for commercial or personal use/public domain as far as I
can tell, so you are more than welcome to use this if you are a content creator.


Program(s) used were: Paint.NET


Sources:
Button Frame Source Image: https://freesvg.org/1540587730

Fonts:
Painting With Chocolate: https://www.dafont.com/painting-with-chocolate.font
Seconds: https://www.dafont.com/seconds.font

CURRENT KNOWN ISSUES:

- The overlay image is too large and will require a lot of downscaling in OBS. Will fix at some point in the future.
