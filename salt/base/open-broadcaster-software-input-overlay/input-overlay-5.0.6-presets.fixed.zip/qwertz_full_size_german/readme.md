Based on the Ubuntu keyboard layout preview.

Project files:
https://drive.google.com/drive/folders/1NzWGgNYEnNTqxm24Fubfg9A6gr6Asa2y

For `qwertz_full_size_german_2.json` see #377.
