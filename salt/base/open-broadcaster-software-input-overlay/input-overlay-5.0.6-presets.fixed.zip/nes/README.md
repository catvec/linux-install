Provided by [AlkHacNar](https://obsproject.com/forum/members/alkhacnar.457634/)
